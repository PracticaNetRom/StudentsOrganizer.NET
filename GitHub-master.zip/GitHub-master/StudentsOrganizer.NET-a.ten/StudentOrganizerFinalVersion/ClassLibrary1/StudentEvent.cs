﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentOrganizer.BO
{
    public class StudentEvent
    {
        
        public int Id_Student { get; set; }
        public int Id_Event { get; set; }
        
    }
}
