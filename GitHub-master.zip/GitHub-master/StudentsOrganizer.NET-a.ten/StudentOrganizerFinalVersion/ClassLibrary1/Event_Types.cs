﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentOrganizer.BO
{
    public class Event_Types
    {
        public int Id { get; set; }
        public string Description { get; set; }
    }
}
